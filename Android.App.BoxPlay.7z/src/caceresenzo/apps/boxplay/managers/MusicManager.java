package caceresenzo.apps.boxplay.managers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import caceresenzo.apps.boxplay.R;
import caceresenzo.apps.boxplay.activities.BoxPlayActivity;
import caceresenzo.apps.boxplay.activities.VideoActivity;
import caceresenzo.apps.boxplay.factory.MusicFactory;
import caceresenzo.apps.boxplay.factory.MusicFactory.MusicFactoryListener;
import caceresenzo.apps.boxplay.managers.XManagers.AManager;
import caceresenzo.apps.boxplay.models.element.MusicElement;
import caceresenzo.apps.boxplay.models.music.MusicFile;
import caceresenzo.apps.boxplay.models.music.MusicGroup;

public class MusicManager extends AManager {
	
	// private static final String JSON_KEY_WATCHING_GROUP = "watching_group";
	// private static final String JSON_KEY_WATCHED_SEASON = "watched_album";
	// private static final String JSON_KEY_DATA_VIDEO = "data_music";
	// private HashMap<Object, Object> mapJsonUserData = new HashMap<Object, Object>();
	// private final File musicStoreDotJsonFile = new File(getManagers().baseDataDirectory, "musicStore.json");
	
	private MusicFactory musicFactory = new MusicFactory();
	private List<MusicGroup> groups;
	
	private MusicFile lastMusicFileOpen;
	
	public void initialize() {
		groups = new ArrayList<MusicGroup>();
	}
	
	public void callFactory() {
		groups.clear();
		
		musicFactory.parseServerJson(new MusicFactoryListener() {
			@Override
			public void onJsonMissingFileType() {
				boxPlayActivity.snackbar("Warning. (Music)Factory returned onJsonMissingFileType();", Snackbar.LENGTH_LONG).show();
			}
			
			@Override
			public void onJsonNull() {
				boxPlayActivity.snackbar(R.string.boxplay_error_manager_json_null, Snackbar.LENGTH_LONG).show();
			}
			
			@Override
			public void onMusicGroupCreated(MusicGroup musicGroup) {
				groups.add(musicGroup);
			}
		}, BoxPlayActivity.getManagers().getDataManager().getJsonData());
		
		// Collections.sort(groups, MusicGroup.COMPARATOR);
		Collections.shuffle(groups);
		
		// prepareConfigurator();
	}
	
	// @SuppressWarnings("unchecked")
	// private void prepareConfigurator() {
	// mapJsonUserData.clear();
	//
	// List<String> watchingGroups = new ArrayList<String>();
	// List<String> watchedSeasons = new ArrayList<String>();
	// HashMap<String, HashMap<String, Object>> dataMusics = new HashMap<String, HashMap<String, Object>>();
	//
	// mapJsonUserData.put(JSON_KEY_WATCHING_GROUP, watchingGroups);
	// mapJsonUserData.put(JSON_KEY_WATCHED_SEASON, watchedSeasons);
	// mapJsonUserData.put(JSON_KEY_DATA_VIDEO, dataMusics);
	//
	// if (!musicStoreDotJsonFile.exists()) {
	// return;
	// }
	//
	// JsonObject json;
	// try {
	// json = (JsonObject) new JsonParser().parse(new FileReader(musicStoreDotJsonFile));
	// } catch (Exception exception) {
	// exception.printStackTrace();
	// return;
	// }
	//
	// try {
	// for (String groupString : (List<String>) json.get(JSON_KEY_WATCHING_GROUP)) {
	// watchingGroups.add(groupString);
	// }
	// } catch (Exception exception) {
	// ;
	// }
	//
	// try {
	// for (String albumString : (List<String>) json.get(JSON_KEY_WATCHED_SEASON)) {
	// watchedSeasons.add(albumString);
	// }
	// } catch (Exception exception) {
	// ;
	// }
	//
	// try {
	// for (Entry<String, HashMap<String, Object>> entry : ((HashMap<String, HashMap<String, Object>>) json.get(JSON_KEY_DATA_VIDEO)).entrySet()) {
	// String musicName = entry.getKey();
	// HashMap<String, Object> data = entry.getValue();
	//
	// dataMusics.put(musicName, data);
	// }
	// } catch (Exception exception) {
	// ;
	// }
	//
	// for (MusicGroup group : groups) {
	// if (watchingGroups.contains(group.toString())) {
	// // group.setAsWatching(true);
	// }
	//
	// for (MusicAlbum album : group.getAlbums()) {
	// if (watchedSeasons.contains(album.toString())) {
	// // album.asWatched(true);
	// }
	//
	// for (MusicFile music : album.getMusics()) {
	// if (dataMusics.containsKey(music.toString())) {
	// HashMap<String, Object> data = dataMusics.get(music.toString());
	//
	// // music.asWatched(ParseUtils.parseBoolean(data.get("watched"), false));
	// // music.newSavedTime(ParseUtils.parseLong(data.get("savedTime"), -1));
	// // music.newDuration(ParseUtils.parseLong(data.get("duration"), -1));
	// }
	// }
	// }
	// }
	// }
	
	/**
	 * 
	 * @param element
	 * @param mode
	 * @param value
	 *            - MusicGroup: WATCHED/UNWATCHED \n- MusicAlbum: WATCHED/UNWATCHED \n- MusicFile: WATCHED, UNWATCHED, TIMEDATA
	 */
	// @SuppressWarnings("unchecked")
	public void callConfigurator(MusicElement element) {
		// if (element == null) {
		// return;
		// }
		//
		// if (element instanceof MusicGroup) { // Add to list
		// MusicGroup group = (MusicGroup) element;
		// List<String> watchingGroup = (List<String>) mapJsonUserData.get(JSON_KEY_WATCHING_GROUP);
		//
		// // if (group.isWatching()) {
		// // watchingGroup.add(group.toString());
		// // } else {
		// // watchingGroup.remove(group.toString());
		// // }
		// } else if (element instanceof MusicAlbum) { // Season has been marked as seen
		// MusicAlbum album = (MusicAlbum) element;
		// List<String> watchedSeason = (List<String>) mapJsonUserData.get(JSON_KEY_WATCHED_SEASON);
		//
		// // if (album.isWatched()) {
		// // watchedSeason.add(album.toString());
		// // } else {
		// // watchedSeason.remove(album.toString());
		// // }
		// } else if (element instanceof MusicFile) { // Music has been marked as saw or time data update
		// MusicFile music = (MusicFile) element;
		// HashMap<String, HashMap<String, Object>> musicDataMap = (HashMap<String, HashMap<String, Object>>) mapJsonUserData.get(JSON_KEY_DATA_VIDEO);
		// HashMap<String, Object> data = new HashMap<String, Object>();
		//
		// // if (music.isWatched()) {
		// // data.put("watched", true);
		// // }
		// // if (music.getSavedTime() > 1 && music.getDuration() != 0) { // Not 0 or -1
		// // data.put("savedTime", music.getSavedTime());
		// // data.put("duration", music.getDuration());
		// // }
		// // TODO: Add queue
		//
		// if (data.isEmpty()) {
		// musicDataMap.remove(music.toString());
		// } else {
		// musicDataMap.put(music.toString(), data);
		// }
		// }
		//
		// JsonObject object = new JsonObject(mapJsonUserData);
		// // DialogUtils.showDialog(MusicActivity.getMusicActivity(), "json", "JSON: " + object.toJsonString());
		// try {
		// getManagers().writeLocalFile(musicStoreDotJsonFile, object.toJsonString());
		// } catch (IOException exception) {
		// exception.printStackTrace();
		// boxPlayActivity.toast("IOException: " + exception.getLocalizedMessage()).show();
		// boxPlayActivity.snackbar(R.string.boxplay_error_config_failed, Snackbar.LENGTH_LONG).show();
		// }
	}
	
	public void playFile(MusicFile musicFile) {
		// TODO: MusicPlayer Service
		
		try {
			Uri uri = Uri.parse(musicFile.getUrl());
			Intent vlcIntent = new Intent(Intent.ACTION_VIEW);
			vlcIntent.setPackage("org.videolan.vlc");
			vlcIntent.setDataAndTypeAndNormalize(uri, "audio/*");
			vlcIntent.putExtra("title", musicFile.getTitle());
			vlcIntent.setComponent(new ComponentName("org.videolan.vlc", "org.videolan.vlc.gui.video.VideoPlayerActivity"));
			
			Activity context;
			if (VideoActivity.getVideoActivity() != null) {
				context = VideoActivity.getVideoActivity();
			} else {
				context = boxPlayActivity;
			}
			context.startActivityForResult(vlcIntent, BoxPlayActivity.REQUEST_ID_VLC_AUDIO);
		} catch (Exception exception) {
			// BoxPlayActivity.getBoxPlayActivity().appendError("Error when starting VLC. \n\nIs VLC installed? \n\nException: " + exception.getLocalizedMessage());
		}
		
		lastMusicFileOpen = musicFile;
	}
	
	public List<MusicGroup> getGroups() {
		return groups;
	}
	
	public MusicFile getLastMusicFileOpen() {
		return lastMusicFileOpen;
	}
	
}