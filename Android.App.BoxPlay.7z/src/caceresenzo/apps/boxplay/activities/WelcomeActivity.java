package caceresenzo.apps.boxplay.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import caceresenzo.apps.boxplay.R;

public class WelcomeActivity extends AppCompatActivity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome);
	}
	
}