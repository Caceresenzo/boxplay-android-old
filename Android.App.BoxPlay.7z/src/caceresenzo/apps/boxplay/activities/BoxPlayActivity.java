package caceresenzo.apps.boxplay.activities;

import com.muddzdev.styleabletoastlibrary.StyleableToast;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import caceresenzo.apps.boxplay.BoxPlayApplication;
import caceresenzo.apps.boxplay.R;
import caceresenzo.apps.boxplay.fragments.ViewHelper;
import caceresenzo.apps.boxplay.fragments.other.SettingsFragment;
import caceresenzo.apps.boxplay.fragments.other.about.AboutFragment;
import caceresenzo.apps.boxplay.fragments.social.SocialFragment;
import caceresenzo.apps.boxplay.fragments.store.StoreFragment;
import caceresenzo.apps.boxplay.fragments.store.StorePageFragment;
import caceresenzo.apps.boxplay.managers.XManagers;
import caceresenzo.libs.comparator.Version;
import caceresenzo.libs.comparator.VersionType;
import it.gmariotti.changelibs.library.internal.ChangeLog;

public class BoxPlayActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
	
	public static final int REQUEST_ID_UPDATE = 20;
	public static final int REQUEST_ID_VLC_VIDEO = 40;
	public static final int REQUEST_ID_VLC_AUDIO = 41;
	public static final int REQUEST_ID_PERMISSION = 100;
	public static final String FILEPROVIDER_AUTHORITY = "caceresenzo.apps.boxplay.provider";
	
	private static BoxPlayActivity INSTANCE;
	private static Handler HANDLER = new Handler();
	private static XManagers MANAGERS = new XManagers();
	private static ViewHelper HELPER = new ViewHelper();
	
	private static final Version VERSION = new Version("3.0.3", VersionType.BETA);
	
	private Toolbar toolbar;
	private DrawerLayout drawer;
	private ActionBarDrawerToggle actionBarDrawerToggle;
	private NavigationView navigationView;
	private CoordinatorLayout coordinatorLayout;
	private Menu optionsMenu;
	
	private ChangeLog changeLog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_boxplay);
		INSTANCE = this;
		
		initializeViews();
		initializeSystems();
		
		MANAGERS.initialize(this) //
				.initializeConfig() //
				.initializePermission() //
				.initializeData() //
				.initializeElements() //
				.initializeUpdate() //
				.finish() //
		;
		
		// if (savedInstanceState == null) {
		// showFragment(new PlaceholderFragment());
		// }
		
		// startActivity(new Intent(this, MoMoney.class));
	}
	
	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		onNavigationItemSelected(navigationView.getMenu().findItem(R.id.drawer_boxplay_store_video));
		navigationView.getMenu().findItem(R.id.drawer_boxplay_store_video).setChecked(true);
		
		if (MANAGERS.getUpdateManager().isFirstRunOnThisUpdate()) {
			MANAGERS.getUpdateManager().saveUpdateVersion();
			HANDLER.postDelayed(new Runnable() {
				@Override
				public void run() {
					HELPER.updateSeachMenu(R.id.drawer_boxplay_other_about);
					showFragment(new AboutFragment().withChangeLog());
				}
			}, 3000);
		}
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, final Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		switch (requestCode) {
			case BoxPlayActivity.REQUEST_ID_VLC_VIDEO: {
				VideoActivity videoActivity = VideoActivity.getVideoActivity();
				if (videoActivity != null) {
					videoActivity.onActivityResult(requestCode, resultCode, data);
				}
				break;
			}
		}
	}
	
	private void initializeViews() {
		toolbar = (Toolbar) findViewById(R.id.activity_video_toolbar_bar);
		setSupportActionBar(toolbar);
		
		drawer = (DrawerLayout) findViewById(R.id.activity_boxplay_drawerlayout_container);
		actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
		drawer.addDrawerListener(actionBarDrawerToggle);
		actionBarDrawerToggle.syncState();
		
		navigationView = (NavigationView) findViewById(R.id.activity_boxplay_navigationview_container);
		navigationView.setNavigationItemSelectedListener(this);
		navigationView.getMenu().getItem(0).setChecked(true);
		
		coordinatorLayout = (CoordinatorLayout) findViewById(R.id.activity_boxplay_coordinatorlayout_container);
	}
	
	private void initializeSystems() {
		HELPER.prepareCache(this);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		if (menu instanceof MenuBuilder) {
			((MenuBuilder) menu).setOptionalIconsVisible(true);
		}
		getMenuInflater().inflate(R.menu.main, menu);
		optionsMenu = menu;
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		// Fragment lastFrament = HELPER.getLastFragment();
		
		switch (id) {
			case R.id.menu_main_action_update:
				MANAGERS.getUpdateManager().showDialog();
				return true;
			case R.id.menu_main_action_search:
			default:
				// if (lastFrament != null && lastFrament instanceof StoreFragment) {
				// return ((StorePageFragment) StoreFragment.getStoreFragment().getActualFragment()).onOptionsItemSelected(item);
				// }
				StorePageFragment.handleSearch(item);
				break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public void onBackPressed() {
		if (drawer.isDrawerOpen(GravityCompat.START)) {
			drawer.closeDrawer(GravityCompat.START);
		} else {
			if (BoxPlayApplication.getBoxPlayApplication().getPreferences().getBoolean(getString(R.string.boxplay_other_settings_menu_pref_drawer_extend_collapse_back_button_key), true)) {
				drawer.openDrawer(GravityCompat.START);
			} else {
				super.onBackPressed();
			}
		}
	}
	
	public void forceFragmentPath(int id) {
		MenuItem targetItem = navigationView.getMenu().findItem(id);
		
		if (targetItem != null) {
			onNavigationItemSelected(navigationView.getMenu().findItem(id));
		}
	}
	
	@Override
	public boolean onNavigationItemSelected(MenuItem item) {
		int id = item.getItemId();
		Fragment actualFragment = HELPER.getLastFragment();
		
		if (item.isCheckable()) {
			HELPER.unselectAllMenu();
		}
		item.setChecked(true);
		HELPER.updateSeachMenu(id);
		
		switch (id) {
			// case R.id.drawer_boxplay_home:
			// showFragment(new PlaceholderFragment());
			// break;
			case R.id.drawer_boxplay_store_video:
			case R.id.drawer_boxplay_store_music:
				// case R.id.drawer_boxplay_store_files:
				StoreFragment storeFragment;
				if (actualFragment != null && actualFragment instanceof StoreFragment) {
					storeFragment = ((StoreFragment) actualFragment);
				} else {
					storeFragment = new StoreFragment();
				}
				switch (id) {
					case R.id.drawer_boxplay_store_video:
						storeFragment = (StoreFragment) storeFragment.withVideo();
						break;
					case R.id.drawer_boxplay_store_music:
						storeFragment = (StoreFragment) storeFragment.withMusic();
						break;
					// case R.id.drawer_boxplay_store_files:
					// storeFragment = (StoreFragment) storeFragment.withFiles();
					// break;
				}
				showFragment(storeFragment);
				break;
			case R.id.drawer_boxplay_connect_feed:
			case R.id.drawer_boxplay_connect_friends:
			case R.id.drawer_boxplay_connect_chat:
				SocialFragment socialFragment;
				if (actualFragment != null && actualFragment instanceof SocialFragment) {
					socialFragment = ((SocialFragment) actualFragment);
				} else {
					socialFragment = new SocialFragment();
				}
				switch (id) {
					case R.id.drawer_boxplay_connect_feed:
						socialFragment = (SocialFragment) socialFragment.withFeed();
						break;
					case R.id.drawer_boxplay_connect_friends:
						socialFragment = (SocialFragment) socialFragment.withFriend();
						break;
					case R.id.drawer_boxplay_connect_chat:
						socialFragment = (SocialFragment) socialFragment.withChat();
						break;
				}
				showFragment(socialFragment);
				break;
			case R.id.drawer_boxplay_other_settings: {
				showFragment(new SettingsFragment());
				break;
			}
			case R.id.drawer_boxplay_other_about: {
				showFragment(new AboutFragment());
				break;
			}
			default: {
				return false;
			}
		}
		drawer.closeDrawer(GravityCompat.START);
		return true;
	}
	
	private void showFragment(Fragment fragment) {
		FragmentManager fragmentManager = getSupportFragmentManager();
		fragmentManager //
				.beginTransaction() //
				.replace(R.id.activity_boxplay_framelayout_container_main, fragment) //
				.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN) //
				.commit() //
		;
		HELPER.setLastFragment(fragment);
	}
	
	public Snackbar snackbar(String text, int duration) {
		Snackbar snackbar = Snackbar.make(coordinatorLayout, text, duration);
		return snackbar;
	}
	
	public Snackbar snackbar(int ressourceId, int duration, Object... args) {
		Snackbar snackbar = Snackbar.make(coordinatorLayout, getString(ressourceId, args), duration);
		return snackbar;
	}
	
	public StyleableToast toast(String string) {
		return StyleableToast.makeText(this, string, R.style.AllStyles);
	}
	
	public StyleableToast toast(int ressourceId, Object... args) {
		return StyleableToast.makeText(this, getString(ressourceId, args), Toast.LENGTH_LONG, R.style.AllStyles);
	}
	
	public Toolbar getToolbar() {
		return toolbar;
	}
	
	public DrawerLayout getDrawer() {
		return drawer;
	}
	
	public ActionBarDrawerToggle getActionBarDrawerToggle() {
		return actionBarDrawerToggle;
	}
	
	public NavigationView getNavigationView() {
		return navigationView;
	}
	
	public CoordinatorLayout getCoordinatorLayout() {
		return coordinatorLayout;
	}
	
	public Menu getOptionsMenu() {
		return optionsMenu;
	}
	
	public ChangeLog getChangeLog() {
		return changeLog;
	}
	
	public static Version getVersion() {
		return VERSION;
	}
	
	public static ViewHelper getViewHelper() {
		return HELPER;
	}
	
	public static XManagers getManagers() {
		return MANAGERS;
	}
	
	public static Handler getHandler() {
		return HANDLER;
	}
	
	public static BoxPlayActivity getBoxPlayActivity() {
		return INSTANCE;
	}
}
