package caceresenzo.apps.boxplay.fragments.other.about;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import caceresenzo.apps.boxplay.R;
import caceresenzo.apps.boxplay.activities.BoxPlayActivity;
import caceresenzo.apps.boxplay.fragments.ViewPagerAdapter;

public class AboutFragment extends Fragment {
	
	public static final int PAGE_ABOUT = 0;
	public static final int PAGE_CHANGELOG = 1;
	public static final int PAGE_LIBRARIES = 2;
	
	private TabLayout tabLayout;
	private ViewPager viewPager;
	private ViewPagerAdapter adapter;
	
	private int onOpenPageId = 0;
	
	public AboutFragment() {
		;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_about, container, false);
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
		if (savedInstanceState == null) {
			viewPager = (ViewPager) getView().findViewById(R.id.fragment_about_viewpager_container);
			setViewPager(viewPager);
			
			tabLayout = (TabLayout) getView().findViewById(R.id.fragment_about_tablayout_container);
			tabLayout.setupWithViewPager(viewPager);
		}
		
		if (viewPager != null) {
			viewPager.setCurrentItem(onOpenPageId, true);
		}
	}
	
	private void setViewPager(ViewPager viewPager) {
		adapter = new ViewPagerAdapter(getChildFragmentManager());
		
		adapter.addFragment(new PageAboutPageFragment(), getString(R.string.boxplay_other_about_about));
		adapter.addFragment(new PageAboutChangeLogFragment(), getString(R.string.boxplay_other_about_changelog));
		adapter.addFragment(new PageAboutLibrariesFragment(), getString(R.string.boxplay_other_about_libraries));
		
		viewPager.setAdapter(adapter);
		viewPager.setOffscreenPageLimit(10);
	}
	
	public AboutFragment withAbout() {
		return withPage(PAGE_ABOUT);
	}
	
	public AboutFragment withChangeLog() {
		return withPage(PAGE_CHANGELOG);
	}
	
	public AboutFragment withLibraries() {
		return withPage(PAGE_LIBRARIES);
	}
	
	public AboutFragment withPage(int pageId) {
		if (viewPager == null) {
			this.onOpenPageId = pageId;
		} else {
			viewPager.setCurrentItem(pageId);
		}
		BoxPlayActivity.getViewHelper().unselectAllMenu();
		BoxPlayActivity.getBoxPlayActivity().getNavigationView().getMenu().findItem(R.id.drawer_boxplay_other_about).setChecked(true);
		return this;
	}
}