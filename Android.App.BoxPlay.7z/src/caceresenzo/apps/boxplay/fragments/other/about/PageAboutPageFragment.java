package caceresenzo.apps.boxplay.fragments.other.about;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import caceresenzo.apps.boxplay.R;
import caceresenzo.apps.boxplay.activities.BoxPlayActivity;
import caceresenzo.apps.boxplay.models.server.ServerHosting;
import mehdi.sakout.aboutpage.AboutPage;
import mehdi.sakout.aboutpage.Element;

public class PageAboutPageFragment extends Fragment {
	
	private View aboutView;
	private List<ServerHosting> servers;
	
	private FrameLayout aboutFrameLayout;
	private RecyclerView hostingRecyclerView;
	
	public PageAboutPageFragment() {
		this.servers = new ArrayList<ServerHosting>();
	}
	
	private void createAboutView() {
		String teamFormat = getString(R.string.boxplay_other_about_group_team_format);
		aboutView = new AboutPage(getActivity()) //
				.isRTL(false) //
				.setImage(R.drawable.icon_boxplay_easter_egg) //
				.setDescription(getString(R.string.boxplay_other_about_description)) //
				.addGroup(getString(R.string.boxplay_other_about_group_app_information)) //
				.addItem(new Element(getString(R.string.boxplay_other_about_group_app_information_version, BoxPlayActivity.getVersion().get()), null)) //
				.addGroup(getString(R.string.boxplay_other_about_group_team_programmer)) //
				.addItem(new Element(String.format(teamFormat, "Enzo CACERES, *Caceresenzo", getString(R.string.boxplay_other_about_group_team_format_type_application)), null)) //
				.addGroup(getString(R.string.boxplay_other_about_group_team_designer)) //
				.addItem(new Element(String.format(teamFormat, "Enzo CACERES, *Caceresenzo", getString(R.string.boxplay_other_about_group_team_format_type_ui)), null)) //
				.addItem(new Element(String.format(teamFormat, "Quentin BOTTA, *valgrebon", getString(R.string.boxplay_other_about_group_team_format_type_icons)), null)) //
				.addGroup(getString(R.string.boxplay_other_about_group_team_supporter)) //
				.addItem(new Element(String.format(teamFormat, "J�r�mie BLERAUD", getString(R.string.boxplay_other_about_group_team_format_type_because)), null)) //
				.addItem(new Element(String.format(teamFormat, "Dorian HARDY, *thegostisdead", getString(R.string.boxplay_other_about_group_team_format_type_hosting)), null)) //
				.addGroup(getString(R.string.boxplay_other_about_group_team_helper)) //
				.addItem(new Element(String.format(teamFormat, "*dandar3", getString(R.string.boxplay_other_about_group_team_format_type_eclipse)), null)) //
				.create() //
		; //
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_about_page, container, false);
		
		createAboutView();
		
		aboutFrameLayout = (FrameLayout) view.findViewById(R.id.fragment_about_page_framelayout_about);
		
		hostingRecyclerView = (RecyclerView) view.findViewById(R.id.fragment_about_page_recyclerview_host_list);
		hostingRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
		hostingRecyclerView.setAdapter(new ServerHostingViewAdapter(this.servers));
		
		return view;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
		aboutFrameLayout.addView(aboutView);
	}
	
	class ServerHostingViewAdapter extends RecyclerView.Adapter<ServerViewHolder> {
		private List<ServerHosting> list;
		
		public ServerHostingViewAdapter(List<ServerHosting> list) {
			this.list = list;
		}
		
		@Override
		public ServerViewHolder onCreateViewHolder(ViewGroup viewGroup, int itemType) {
			View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_about_libraries_cardview, viewGroup, false);
			return new ServerViewHolder(view);
		}
		
		@Override
		public void onBindViewHolder(ServerViewHolder viewHolder, int position) {
			ServerHosting item = list.get(position);
			viewHolder.bind(item);
		}
		
		@Override
		public int getItemCount() {
			return list.size();
		}
	}
	
	class ServerViewHolder extends RecyclerView.ViewHolder {
		private TextView contentTextView;
		
		public ServerViewHolder(View itemView) {
			super(itemView);
			
			contentTextView = (TextView) itemView.findViewById(R.id.item_about_libraries_layout_textview_content);
		}
		
		public void bind(ServerHosting ServerHosting) {
			// contentTextView.setText(getString(R.string.boxplay_other_about_libraries_format, ServerHosting.getName(), ServerHosting.getAuthor()));
		}
	}
	
}